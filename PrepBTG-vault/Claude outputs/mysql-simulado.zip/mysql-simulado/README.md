# mysql-simulado — banco do case iFood

MySQL 8.4 em Docker com o dataset `data/raw` de andsfonseca/ifood-case-data-science
(offers.json, profile.json, transactions.json), carregado **como vem** (sem limpeza).

## Subir (no WSL)
```bash
cd ~/docker/containers/mysql-simulado
sudo docker compose up -d
sudo docker logs -f mysql-simulado      # espere "ready for connections" (carga leva ~1 min)
sudo docker exec -it mysql-simulado mysql -uanalista -panalista123 ifood -e "SELECT * FROM vw_contagem_carga"
```
Esperado: offers 10 · offer_channels 33 · profile 17000 · transactions 306534.

Recarregar do zero: `sudo docker compose down -v && sudo docker compose up -d`
(os scripts de `init/` só rodam com o volume vazio).

## DBeaver
Host `localhost`, porta **3307**, banco `ifood`, usuário `analista` / `analista123` (ou `root` / `simulado_root`).
Driver properties: `allowPublicKeyRetrieval=true`, `useSSL=false`.

## Python
```bash
cd python && pip install -r requirements.txt && python teste_conexao.py
```
`from conexao import consulta; df = consulta("SELECT ...")`

## Tabelas
| Tabela | Origem | Colunas |
|---|---|---|
| `offers` | offers.json | id, offer_type (bogo/discount/informational), min_value, discount_value, duration (dias) |
| `offer_channels` | offers.json → channels | offer_id, channel (web/email/mobile/social) |
| `profile` | profile.json | id, age, gender, registered_on (DATE), credit_card_limit |
| `transactions` | transactions.json | transaction_id, event, account_id → profile.id, offer_id → offers.id, amount, reward, time_since_test_start (dias, 0 a 29,75) |

## Armadilhas do dado original
- 2.175 perfis com `age = 118`, `gender` NULL e `credit_card_limit` NULL: é o mesmo grupo (idade ausente).
- No JSON, `value` usa `"offer id"` em received/viewed e `"offer_id"` em completed; aqui as duas viraram `offer_id`.
- `amount` só existe em `event = 'transaction'`; `reward` só em `'offer completed'`. Transação **não** traz offer_id: ligar compra à oferta é pela janela de tempo (`time_since_test_start` entre o received e received + duration).
- Ofertas `informational` nunca são "completed".
