-- Banco do simulado: dataset do case iFood (andsfonseca/ifood-case-data-science, data/raw)
-- Dados carregados como vêm no JSON (sem limpeza): idade 118 e gender/limite nulos ficam como estão.
CREATE DATABASE IF NOT EXISTS ifood CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE ifood;

-- offers.json: 10 ofertas
CREATE TABLE offers (
  id              CHAR(32)     NOT NULL PRIMARY KEY,
  offer_type      VARCHAR(20)  NOT NULL COMMENT 'bogo, discount, informational',
  min_value       DECIMAL(8,2) NOT NULL COMMENT 'gasto mínimo para completar a oferta',
  discount_value  DECIMAL(8,2) NOT NULL COMMENT 'desconto/recompensa',
  duration        DECIMAL(4,1) NOT NULL COMMENT 'validade em dias'
) ENGINE=InnoDB;

-- offers.json -> channels (lista) normalizada: 1 linha por oferta x canal
CREATE TABLE offer_channels (
  offer_id  CHAR(32)    NOT NULL,
  channel   VARCHAR(10) NOT NULL COMMENT 'web, email, mobile, social',
  PRIMARY KEY (offer_id, channel),
  CONSTRAINT fk_oc_offer FOREIGN KEY (offer_id) REFERENCES offers(id)
) ENGINE=InnoDB;

-- profile.json: 17.000 clientes
CREATE TABLE profile (
  id                 CHAR(32)      NOT NULL PRIMARY KEY,
  age                INT           NOT NULL COMMENT '118 = idade ausente no dado original',
  gender             CHAR(1)       NULL     COMMENT 'M, F, O ou NULL',
  registered_on      DATE          NOT NULL,
  credit_card_limit  DECIMAL(12,2) NULL
) ENGINE=InnoDB;

-- transactions.json: 306.534 eventos (o campo "value" foi achatado em colunas)
CREATE TABLE transactions (
  transaction_id         INT          NOT NULL PRIMARY KEY COMMENT 'ordem da linha no JSON (criado na carga)',
  event                  VARCHAR(20)  NOT NULL COMMENT 'transaction, offer received, offer viewed, offer completed',
  account_id             CHAR(32)     NOT NULL,
  offer_id               CHAR(32)     NULL     COMMENT 'une "offer id" (received/viewed) e "offer_id" (completed)',
  amount                 DECIMAL(10,2) NULL    COMMENT 'só em event = transaction',
  reward                 DECIMAL(8,2) NULL     COMMENT 'só em event = offer completed',
  time_since_test_start  DECIMAL(5,2) NOT NULL COMMENT 'dias desde o início do teste (0 a 29,75)',
  KEY ix_tr_account (account_id, time_since_test_start),
  KEY ix_tr_event (event),
  KEY ix_tr_offer (offer_id),
  CONSTRAINT fk_tr_profile FOREIGN KEY (account_id) REFERENCES profile(id),
  CONSTRAINT fk_tr_offer   FOREIGN KEY (offer_id)   REFERENCES offers(id)
) ENGINE=InnoDB;
