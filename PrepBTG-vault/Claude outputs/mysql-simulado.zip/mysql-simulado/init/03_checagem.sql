USE ifood;
CREATE OR REPLACE VIEW vw_contagem_carga AS
SELECT 'offers' AS tabela, COUNT(*) AS linhas FROM offers
UNION ALL SELECT 'offer_channels', COUNT(*) FROM offer_channels
UNION ALL SELECT 'profile', COUNT(*) FROM profile
UNION ALL SELECT 'transactions', COUNT(*) FROM transactions;
