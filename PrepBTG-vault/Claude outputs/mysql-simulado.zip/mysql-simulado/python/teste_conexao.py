from conexao import consulta

print(consulta("SELECT * FROM vw_contagem_carga"))
print("\nEsperado: offers 10 | offer_channels 33 | profile 17000 | transactions 306534")
