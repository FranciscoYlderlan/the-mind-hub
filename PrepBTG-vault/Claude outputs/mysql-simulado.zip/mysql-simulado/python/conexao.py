"""Conexão com o banco do simulado (ifood). Lê o ../.env."""
from pathlib import Path
import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
import pandas as pd

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

def engine():
    url = (f"mysql+pymysql://{os.getenv('MYSQL_USER')}:{os.getenv('MYSQL_PASSWORD')}"
           f"@{os.getenv('MYSQL_HOST', 'localhost')}:{os.getenv('MYSQL_PORT', '3307')}"
           f"/{os.getenv('MYSQL_DATABASE', 'ifood')}?charset=utf8mb4")
    return create_engine(url)

def consulta(sql: str, **params) -> pd.DataFrame:
    """Roda um SELECT e devolve um DataFrame."""
    from sqlalchemy import text
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=params)
